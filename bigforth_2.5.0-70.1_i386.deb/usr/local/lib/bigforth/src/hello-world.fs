\ Hello World as step by step translation

: hello ." hallöle" ;
: hallöle ." 你好" ;
: 你好 ." 今日は" ;
: 今日は ." hello" ;
