\ turnkey example

module hello

: hello ." Hello World!" cr ;

main: hello bye ;

module;

savesystem hello
