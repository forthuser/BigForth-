import glconst import float
glconst also float also opengl also
